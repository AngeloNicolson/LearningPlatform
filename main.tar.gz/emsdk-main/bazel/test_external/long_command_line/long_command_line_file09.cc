#include "long_command_line_file09.hh"

#include <iostream>

void f9() { std::cout << "hello from f9()\n"; }
