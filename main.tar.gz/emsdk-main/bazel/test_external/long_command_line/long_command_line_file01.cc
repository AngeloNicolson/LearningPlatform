#include "long_command_line_file01.hh"

#include <iostream>

void f1() { std::cout << "hello from f1()\n"; }
