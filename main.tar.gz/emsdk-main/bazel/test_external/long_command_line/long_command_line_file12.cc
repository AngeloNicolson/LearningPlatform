#include "long_command_line_file12.hh"

#include <iostream>

void f12() { std::cout << "hello from f12()\n"; }
