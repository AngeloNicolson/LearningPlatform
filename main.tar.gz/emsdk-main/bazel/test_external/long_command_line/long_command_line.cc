#include "long_command_line_file01.hh"
#include "long_command_line_file02.hh"
#include "long_command_line_file03.hh"
#include "long_command_line_file04.hh"
#include "long_command_line_file05.hh"
#include "long_command_line_file06.hh"
#include "long_command_line_file07.hh"
#include "long_command_line_file08.hh"
#include "long_command_line_file09.hh"
#include "long_command_line_file10.hh"
#include "long_command_line_file11.hh"
#include "long_command_line_file12.hh"
#include "long_command_line_file13.hh"
#include "long_command_line_file14.hh"
#include "long_command_line_file15.hh"
#include "long_command_line_file16.hh"
#include "long_command_line_file17.hh"
#include "long_command_line_file18.hh"
#include "long_command_line_file19.hh"
#include "long_command_line_file20.hh"

int main() {
  f1();
  f2();
  f3();
  f4();
  f5();
  f6();
  f7();
  f8();
  f9();
  f10();
  f11();
  f12();
  f13();
  f14();
  f15();
  f16();
  f17();
  f18();
  f19();
  f20();
}
